exports.PORT = 7000;

exports.DB_NAME = "asahdatabase";
exports.DB_USER = "root";
exports.DB_PASSWORD = "Jangan6565!";

exports.SESS_COOKIE = "usercloud";
exports.SESS_SECRET = "asahjuournalambitious";

exports.MAIL_USERNAME = "asahjournal@gmail.com";
exports.MAIL_PASSWORD = "Jangan6565!";
exports.OAUTH_CLIENTID =
  "572721469808-95il64ufle0bku8l94iuuvkbdd0b516v.apps.googleusercontent.com";
exports.OAUTH_CLIENT_SECRET = "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";
exports.OAUTH_ACCESS_TOKEN =
  "ya29.A0AVA9y1tcRyqQSEjylxxVIQxyNoQA4WpYKyog1B6VEx0xYUu1Gc3mr1pp2q5y_YbwcVV1RnDxdwSAdzNisGJF2f1GhzBJ-FIND0Pkd8byLwe3-ZP0rlzAewx-h23F9lC3gpmX454WSQmjm5vIG4m086KmdOrZYUNnWUtBVEFTQVRBU0ZRRl91NjFWemV3VWRnUXZxaVRLTE4xYmhWN0gtZw0163";
exports.OAUTH_REFRESH_TOKEN =
  "1//04QNZ-jr-NAfkCgYIARAAGAQSNwF-L9Irn2BK1_KTDntcQBV6uKpqhffqmzUNMLYimfAO8_re6q92SkRYFfIi8jATFJZRZjEaQz4";

exports.AWS_ACCESS_KEY_ID = "AKIA6QJ3AH2CMRGBGTNF";
exports.AWS_SECRET_ACCESS_KEY = "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";
exports.AWS_S3_BUCKET = "asahjournalstorage";
