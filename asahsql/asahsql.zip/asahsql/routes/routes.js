const express = require("express");
const Router = express.Router();
const control = require("../controlers/controlers");
const UserSchema = require("../models/User");
const bcrypt = require("bcryptjs");
const s3 = require("../api/s3");

//Post
Router.get("/", control.HomePage);
Router.get("/category/:category", control.CategoryPage);
Router.get("/allpagehistory", control.AllPostPage);
Router.post("/submit", control.CreatePost);
Router.post("/submitprofile", control.CreateProfilePost);
Router.get("/postparticle/:id", control.PostById);
Router.get("/updatepost/:id", control.UpdateForm);
Router.post("/updatepost/:id", control.UpdatePost);
Router.get("/deletepost/:id", control.DeletePost);
Router.post("/search", control.SearchItem);

//Admin
Router.get("/admin", control.AdminPage);
Router.get("/accept/:id", control.AcceptPost);
Router.get("/acceptpayment/:id", control.AcceptPayment);
Router.get("/acceptwithdraw/:id", control.WithdrawAccept);
Router.get("/sendmail", control.SendEmailToUser);

//User
Router.get("/login", control.LoginPage);
Router.post("/login", control.LoginCommand);
Router.get("/register", control.RegisterPage);
Router.post("/register", control.RegisterCommand);
Router.get("/logout", control.LogoutCommand);
Router.get("/userparticle/:id", control.UserById);
Router.get("/profile", control.LoginId);
Router.get("/userverif/:verificationcode", control.VerifUser);
Router.get("/updateuser/:id", control.UpdateUserForm);
Router.post("/updateuser/:id", control.UpdateUser);
Router.post("/resetpass", control.SendResetPasswordPage);
Router.get("/resetpassword/:resetpass", control.ResetPasswordPage);
Router.post("/resetpassword/:resetpass", control.ResetPassword);

//Payment
Router.get("/payment", control.PaymentPage);
Router.post("/payment", control.PaymentCommand);
Router.get("/paymentupdate/:id", control.PaymentUpdatePage);
Router.post("/paymentupdate/:id", control.PaymentUpdate);
Router.get("/paymentdelete/:id", control.PaymentDelete);
Router.get("/viewpayment/:id", control.ViewPayment);
Router.get("/buypost/:id", control.BuyPost);
Router.get("/withdraw", control.WithdrawPage);
Router.post("/withdraw", control.WithdrawCommand);
Router.get("/withdrawdelete/:id", control.WithdrawDelete);

//404
Router.get("/404", control.PageErr);

//Get AWS File
Router.get("/getfile/:folder/:key", async (req, res) => {
  let folder = req.params.folder;
  let key = req.params.key;

  try {
    let fileToSend = await s3.getFileFromS3(folder, key);
    fileToSend.pipe(res);
  } catch (error) {
    res.send({ error: "Server Error" });
  }
});

Router.get("/getfile/:folder/default/:key", async (req, res) => {
  let folder = req.params.folder;
  let key = req.params.key;

  try {
    let fileToSend = await s3.getFileDefaultFromS3(folder, key);
    fileToSend.pipe(res);
  } catch (error) {
    res.send({ error: "Server Error" });
  }
});

// Router.get("/function", (req, res) => {
//   let text = "default/items";
//   if (text.includes("default")) console.log("text contain default");
//   else console.log("text is clear");
// });

// Jangan dipakai!!!

Router.get("/createadmin", async (req, res) => {
  const salt = bcrypt.genSaltSync(12);
  UserSchema.create({
    username: "superadmin",
    email: "superadmin@asah.com",
    password: bcrypt.hashSync("Jangan6565!", salt),
    admin: true,
    verify: true,
  }).then((data) => {
    if (data) console.log(`Admin ${data.username} created.`);
  });
});

module.exports = Router;
